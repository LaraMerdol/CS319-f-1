// Forget password

// Assign Role to User  ---- Bu tamam
// Add Student To Section   ---- Bu tamam
// Create Project

// Insert peer Review to the Student.

// Get peer reviews.

// GetArtifact Review.

// Give Artifact Review

// Get Sections

// Get Group Information

// Contact Us
function contactUS() {
    let nameOfContact = document.getElementById("Options");
    let emailOfContact = document.getElementById("emailOfContact");
    let findUsHow = document.getElementById("findUsHow");
    let choiceOfFindUs = findUsHow.options[findUsHow.selectedIndex].text;
    let messageOfUser = document.getElementById("messageOfUser");
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080//OtherController/insertContactUsInfo?nameOfContact='+nameOfContact+"&emailOfContact="+emailOfContact+"&findUsHow="+findUsHow+"&choiceOfFindUs="+choiceOfFindUs+"&messageOfUser="+messageOfUser);
    httpRequest.onload = function () {
        let result = httpRequest.responseText;
        alert("The result of contactUS is " + result);
    }
    httpRequest.send();
}