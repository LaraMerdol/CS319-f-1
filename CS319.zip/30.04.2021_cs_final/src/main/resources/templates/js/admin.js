const buttonAssignRole = document.getElementById("buttonAssignRole");
const buttonCreateSection = document.getElementById("buttonCreateSection");
const buttonAddUser = document.getElementById("buttonAddUser");

buttonAssignRole.addEventListener("click", function (e) {
  e.preventDefault();
  let UserID = parseInt(document.getElementById("RoleUserID").value);
  let sectionNumber = document.getElementById("Options").value;
  console.log(UserID);
  console.log(sectionNumber);
});

buttonCreateSection.addEventListener("click", function (e) {
  e.preventDefault();
  let instructorID = parseInt(document.getElementById("InstructorID").value);
  let sectionNumber = parseInt(document.getElementById("sectionNumber").value);
  console.log(instructorID);
  console.log(sectionNumber);
});

buttonAddUser.addEventListener("click", function (e) {
  e.preventDefault();
  let userID = parseInt(document.getElementById("AssignUserID").value);
  let sectionNumber = parseInt(
    document.getElementById("AssignSectionNumber").value
  );
  console.log(userID);
  console.log(sectionNumber);
});

function assignRoleToUser() {
  // Get role From User
  // Sunu default olarak Instructor yaptim
  let selectElement = document.getElementById("Options");
  let role = selectElement.options[selectElement.selectedIndex].text;
  let schoolID = document.getElementById("RoleUserID");
  let httpRequest = new XMLHttpRequest();
  httpRequest.overrideMimeType("application/json");
  httpRequest.open("GET", 'http://localhost:8080//UserController/assignRoleToUser?schoolID='+schoolID+"$role="+role);
  httpRequest.onload = function () {
    let result = httpRequest.responseText;
    alert("The result of assignRoleToUser is " + result);
  }
  httpRequest.send();
}

function createCourse() {
  let instructorID = document.getElementById("InstructorID");
  let sectionNumber = document.getElementById("sectionNumber");
  let httpRequest = new XMLHttpRequest();
  httpRequest.overrideMimeType("application/json");
  httpRequest.open("GET", 'http://localhost:8080//SectionController/addSection?sectionNumber='+sectionNumber+"instructorID="+instructorID);
  httpRequest.onload = function () {
    let result = httpRequest.responseText;
    alert("The result of createCourse is " + result);
  }
  httpRequest.send();
}

function addSection() {
  let schoolID = document.getElementById("AssignUserID");
  let sectionNumber = document.getElementById("AssignSectionNumber");
  let httpRequest = new XMLHttpRequest();
  httpRequest.overrideMimeType("application/json");
  httpRequest.open("GET", 'http://localhost:8080//SectionController/addUserToSection?schoolID='+schoolID+"sectionNumber="+sectionNumber);
  httpRequest.onload = function () {
    let result = httpRequest.responseText;
    alert("The result of createCourse is " + result);

  }
  httpRequest.send();
}