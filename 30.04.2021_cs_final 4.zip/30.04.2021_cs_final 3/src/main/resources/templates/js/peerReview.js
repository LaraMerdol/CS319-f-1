var defaultThemeColors = Survey.StylesManager.ThemeColors["modern"];
defaultThemeColors["$header-color"] = "#AFAEB4"
defaultThemeColors["$answer-background-color"] = "#AFAEB4";
defaultThemeColors["$main-hover-color"] = "#AFAEB4";
defaultThemeColors["$main-color"] = "#AFAEB4";

Survey.StylesManager.applyTheme("modern");


let json = { title: "Tell us, what technologies do you use?", pages: [
        { name:"page1", questions: [
                { type: "radiogroup", choices: [ "Yes", "No" ], isRequired: true, name: "frameworkUsing",title: "Do you use any front-end framework like Bootstrap?" },
                { type: "checkbox", choices: ["Bootstrap","Foundation"], hasOther: true, isRequired: true, name: "framework", title: "What front-end framework do you use?", visibleIf: "{frameworkUsing} = 'Yes'" }
            ]},
        { name: "page2", questions: [
                { type: "radiogroup", choices: ["Yes","No"],isRequired: true, name: "mvvmUsing", title: "Do you use any MVVM framework?" },
                { type: "checkbox", choices: [ "AngularJS", "KnockoutJS", "React" ], hasOther: true, isRequired: true, name: "mvvm", title: "What MVVM framework do you use?", visibleIf: "{mvvmUsing} = 'Yes'" } ] },
        { name: "page3",questions: [
                { type: "comment", name: "about", title: "Please tell us about your main requirements for Survey library" } ] }
    ]
}

window.survey = new Survey.Model(json);


survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
    });

survey.data = {
    satisfaction: 2
};

$("#surveyElement").Survey({model: survey});

/*
let httpRequest = new XMLHttpRequest();
httpRequest.overrideMimeType("application/json");
httpRequest.open("GET", 'http://localhost:8080/PeerReviewController/getPeerReviewQuestions');
alert(httpRequest.responseText[1]);

    let id = localStorage.getItem(id);
    const question = { questionText: document.getElementById("OpenEndedQ").value};
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/PeerReviewController/getPeerReviewQuestions');
    httpRequest.onload = function () {
        alert("openEnded");

    }
    httpRequest.send();
    let array= new Array();
    array = JSON.parse(httpRequest.responseText);
    document.getElementById("OpenEndedquestions").appendChild(li); */