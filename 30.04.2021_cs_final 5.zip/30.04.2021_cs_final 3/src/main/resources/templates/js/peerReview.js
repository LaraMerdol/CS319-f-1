var defaultThemeColors = Survey.StylesManager.ThemeColors["modern"];
defaultThemeColors["$header-color"] = "#AFAEB4"
defaultThemeColors["$answer-background-color"] = "#AFAEB4";
defaultThemeColors["$main-hover-color"] = "#AFAEB4";
defaultThemeColors["$main-color"] = "#AFAEB4";

Survey.StylesManager.applyTheme("modern");
let json = getPeerQuestion();


function getPeerQuestion() {
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/PeerReviewController/getPeerReviewQuestions');
    httpRequest.onload = function () {
        let json = httpRequest.responseText;
        // alert(json);
        return parse(json);
    }
    httpRequest.send();
}
// let json = {
//     "pages": [
//         {
//             "elements": [
//                 {
//                     "type": "radiogroup",
//                     "name": "question1",
//                     "choices": [
//                         "item1",
//                         "item2",
//                         "item3"
//                     ]
//                 },
//                 {
//                     "type": "rating",
//                     "name": "question2",
//                     "rateMax": 7
//                 },
//                 {
//                     "type": "text",
//                     "name": "question3"
//                 }
//             ]
//         }
//     ]
// };
// };

window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
    });

survey.data = {
    satisfaction: 2
};

$("#surveyElement").Survey({model: survey});