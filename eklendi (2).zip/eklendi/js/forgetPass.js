function sendForgetPasswordRequest(){
    alert("Your change password request has sent to admin");
    window.location.href = "sign_in.html";
    window.location.href = "sign_in.html";

}