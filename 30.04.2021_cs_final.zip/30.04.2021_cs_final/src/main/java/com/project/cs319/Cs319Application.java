package com.project.cs319;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Hashtable;

@SpringBootApplication
public class Cs319Application {

    public static void main(String[] args) {
        SpringApplication.run(Cs319Application.class, args);

    }
}
