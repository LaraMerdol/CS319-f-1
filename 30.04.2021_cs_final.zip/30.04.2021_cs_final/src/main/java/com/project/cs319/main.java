package com.project.cs319;

import com.mongodb.client.*;
import com.project.cs319.Controller.CurrentSystemInfoController;
import com.project.cs319.Controller.ForgetPasswordController;
import com.project.cs319.Controller.GroupFormationController;
import org.bson.Document;

public class main {
    public static void main(String [] args)
    {
        ForgetPasswordController fgp = new ForgetPasswordController();
        GroupFormationController gfc = new GroupFormationController();
        CurrentSystemInfoController csi = new CurrentSystemInfoController();
        /*
        fgp.performForgetPassword("asdfasdsadasas", 123);
        fgp.performForgetPassword("lara.merdol@gmail", 111);
        fgp.performForgetPassword("lara.merdol@gmail.com", 111);





        csi.deleteAllSemester();

         */


        gfc.addGithubLink("asgfsagsagas", "CS319-1a", "sagasgasgsagsgas");
    }
}
