package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;
import org.bson.BsonDocument;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
@RequestMapping("/SignUpController")
public class SignUpController {

   private mongoDB database;

    public SignUpController()
    {
        database = new mongoDB();
    }

    @GetMapping("/signUp")
    public void signUp( String name, String surname, String email, String password , int schoolID, String userRole){
        database = new mongoDB();

        User u = new User(name, surname, email, database.secretPassword(password), schoolID, userRole);
        database.insertUser(u);
    }

    @GetMapping("/login")
    public JSONObject login(JSONObject schoolID) throws JSONException {
        database = new mongoDB();
        System.out.println(schoolID.get("id"));
        User u1 = database.getUser((Integer) schoolID.get("id"));
        JSONObject obj = new JSONObject();
        obj.put("name",u1.getName());
        obj.put("surname", u1.getSurname());
        obj.put("email", u1.getEmail());
        obj.put("password", u1.getPassword());

        return obj;
    }
    @GetMapping("/login1")
    public int getA(@RequestParam JSONObject a)
    {
        System.out.println(a.length());
        return 5;
    }





}
