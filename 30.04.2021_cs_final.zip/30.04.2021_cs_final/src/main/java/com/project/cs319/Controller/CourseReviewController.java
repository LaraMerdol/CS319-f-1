package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/CourseReviewController")
public class CourseReviewController {

    public static  mongoDB database;

    public CourseReviewController()
    {
        database = new mongoDB();
    }

    public boolean insertOpenEndedQuestionCourse(String question)
    {

        return database.insertOpenEndedQuestionCourse(question);
    }

    public boolean insertMultipleChoiceQuestionCourse(String question, ArrayList<String> choices)
    {
        return database.insertMultipleChoiceQuestionCourse(question,choices);
    }

    public boolean insertPointQuestionCourse(String question, int outOfGrade)
    {
        return database.insertPointQuestionCourse(question,outOfGrade);
    }

    public ArrayList<Question> getCourseReviewQuestions()
    {
        return database.getCourseReviewQuestions();
    }

    public boolean giveAnswerQuestionsCourse(int giverId, ArrayList<String> answer)
    {
        return database.giveAnswerQuestionsCourse(giverId,answer);
    }
    public ArrayList<ArrayList<String>> getCourseReviewAnswers()
    {
        return database.getCourseReviewAnswers();
    }

}
