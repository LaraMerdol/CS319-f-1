package com.project.cs319.Controller;
import com.project.cs319.Entity.*;
import com.project.cs319.DataBase.*;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ProfileController")
public class ProfileController {

    private mongoDB database;

    public ProfileController()
    {
        database = new mongoDB();
    }


    // Student-------------------------------------------------------------------------

    public Student getStudentInformation(int studentID)
    {
        return database.getStudentInformation(studentID);
    }

    // Instructor-------------------------------------------------------------------------

    public Instructor getInstructorInformation(int instructorID)
    {
        return  database.getInstructorInformation(instructorID);
    }

    // TA-------------------------------------------------------------------------

    public TA getTAInformation(int TAid)
    {
        return database.getTAInformation(TAid);
    }

    //-------------------------------------------------------------------------
    public Hashtable<Integer,ArrayList<String >> getSpecificPeerReviewOfStudent(int receiverID)
    {
       return database.getSpecificPeerReviewOfStudent(receiverID);
    }


}
