let user;

function loginToSystem() {
    // Variables
    let pass =document.getElementById("Pass").value;
    let userName = parseInt(document.getElementById("Uname").value);
    // Http Protocol
    let result = "false";
    let httpRq = new XMLHttpRequest();
    httpRq.overrideMimeType("application/json");
    httpRq.open("GET", 'http://localhost:8080/SignUpController/validateUser?schoolID='+userName+'&password='+pass);
    httpRq.onload = function () {
        result = httpRq.responseText;
        if(result === "true") {
            let httpRequest = new XMLHttpRequest();
            httpRequest.overrideMimeType("application/json");
            httpRequest.open("GET", 'http://localhost:8080/SignUpController/login?schoolID='+parseInt(document.getElementById("Uname").value));
            httpRequest.onload = function () {
                user = JSON.parse(httpRequest.responseText);
                localStorage.setItem("id", document.getElementById("Uname").value);
                localStorage.setItem("name",user["name"]);
                localStorage.setItem("surname", user["surname"]);
                localStorage.setItem("email", user["email"]);
                localStorage.setItem("userRole",user["userRole"]);
                goDash();
            }
            httpRequest.send();
        } else {
            alert("Invalid Username or Password.");
            document.getElementById("Pass").innerText = "";
            document.getElementById("Uname").innerText = "";
        }
    }
    httpRq.send();
}

function signUp() {
    let name = document.getElementById("Name").value;
    let surname = document.getElementById("Surname").value;
    let id = parseInt(document.getElementById("ID").value,10);
    let pass= document.getElementById("sign_up_pass").value;
    let confirmpass = document.getElementById("ConfirmPass").value;
    let email = document.getElementById("EMail").value;
    let userRole = "user";
    if(confirmpass == pass) {
        let httpRequest = new XMLHttpRequest();
        httpRequest.overrideMimeType("application/json");
        httpRequest.open("GET", 'http://localhost:8080/SignUpController/signUp?name='+name+'&surname='+surname
            +'&email='+email+'&password='+pass+'&schoolID='+id+'&userRole='+userRole);
        httpRequest.onload = function () {
        }
        httpRequest.send();
    } else {
        alert("Passwords are not matching!");
    }
}

function goDash(){
    if(localStorage.getItem("userRole")=== "student"){
        window.location.href = "DashboardStudent.html";
    }
    else if(localStorage.getItem("userRole")=== "instructor" || localStorage.getItem("userRole")=== "TA" ){
        window.location.href = "DashboardInstructor.html";
    } else {
        alert("Ups.. Since you are not enrolled to any course, you cannot enter the system.");
    }
} 