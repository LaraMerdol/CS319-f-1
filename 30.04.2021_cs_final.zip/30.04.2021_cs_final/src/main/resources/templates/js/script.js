

const NAME = Symbol();
const PASS = Symbol();
const TYPE = Symbol();
class User {

 set uname(uname){
    this[NAME]=uname;

  }
 set pass(pass){
    this[PASS]=pass;

  }
 set type(type){
    this[TYPE]=type;

  }  
 get uname(){
    return this[NAME];

  }
 get pass(){
    return this[PASS];

  } 
 get type(){
    return this[TYPE];


}
}

const user = new User( );
function loginToSystem() {
  localStorage.setItem("name", document.getElementById("Uname").value);

  user.uname = document.getElementById("Uname").value;
  user.pass =document.getElementById("Pass").value ;

/*
        let httpRequest = new XMLHttpRequest();
        httpRequest.overrideMimeType("application/json");
        httpRequest.open("GET", 'http://localhost:8080/SignUpController/login1');
        httpRequest.onload = function ()
        {
            console.log(httpRequest.responseText);
            console.log("geldimmmmmmm");
        }
        httpRequest.send(user.uname);

 */
    let data = new FormData();
    data.append('parameter_1', 'value parameter 1');
    data.append('parameter_2', 'value parameter 2');

    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost:8080/SignUpController/login1', true);
    xhr.onload = function () {
        console.log(this.responseText);
    };
    xhr.send(data);





/*

    if(user.uname== "" && user.pass == "12345"){
    localStorage.setItem("type", "student");
    user.type = "student";
    window.location.href = "DashboardStudent.html";
  }
  if(user.uname== "Eray" && user.pass == "12345"){
    localStorage.setItem("type", "instructor");
    user.type = "instructor";
    window.location.href = "DashboardInstructor.html";
  }

*/

}




localStorage.setItem(user.uname, "Smith");
function goDash(){

  if(localStorage.getItem("type")== "student"){
    window.location.href = "DashboardStudent.html";
  }
  else if(localStorage.getItem("type")== "instructor"){
    window.location.href = "DashboardInstructor.html";
  }
} 