 
package com.test.ajax;

public class DWRTest {
    public DWRTest(){

    }
    public String getMyName(){   
        return "Hello Ajax";   
    }   

}