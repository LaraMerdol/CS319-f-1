package com.project.cs319;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs319Application {

    public static void main(String[] args) {
        SpringApplication.run(Cs319Application.class, args);
    }

}
