let members = new Array();
var member1={name:"Güven"};
var member2={name:"Lara"};
members.push(member1);
members.push(member2);
let artifact = {
    url:"https://github.com/LaraMerdol/CS319-f-1/tree/main",
    comment:"Hello! this is group1A profile page you can find our github link below.."
}
// Add member to group
function addMemberToGroup() {
    //int studentID, String groupName,int sectionID
    let groupID = localStorage.getItem("groupId");
    let studentID = parseInt(localStorage.getItem("id"));
    let sectionID = parseInt(localStorage.getItem("section"));
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/notRandomGeneratorAddMember?groupID='+groupID+'&studentID='+studentID+'&sectionID='+sectionID);
    httpRequest.onload = function () {
        let returnMessage = httpRequest.responseText;
        alert("The returnMessage is " + returnMessage);
    }
    httpRequest.send();
}

// Remove member from group
function removeUserFromGroup() {
    // Remove student text varsayimsal bir id, kutuya ne verdiyseniz ekleyin
    let studentID = localStorage.getItem("removeStudentText");
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/GroupFormationController/removeUserFromGroup?studentID='+parseInt(localStorage.getItem("id")));
    httpRequest.onload = function () {
        let message = httpRequest.responseText;
        alert("The message from remove student function " + message);
    }
    httpRequest.send();
}

function getStudentsGroup() {
    let httpRequest = new XMLHttpRequest();
    let studentID = parseInt(localStorage.getItem("id"));
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/ProfileController/getStudentsGroup?studentID='+parseInt(localStorage.getItem("id")));
    httpRequest.onload = function () {
        let groupId = httpRequest.responseText;
        localStorage.setItem("groupID", groupId);
        alert("group section of user is " + groupID);
    }
    httpRequest.send();
}


localStorage.setItem("myGroup","groupA");
function myFunction() {

    document.getElementById("Groupname").innerHTML =localStorage.getItem("viewGroupProfileName");
    if(document.getElementById("Groupname").innerHTML!== localStorage.getItem("myGroup")){
        document.getElementById("uploadedFile").style.visibility = "hidden";
        document.getElementById("reviewFiles").style.visibility = "hidden";
        document.getElementById("row2").style.visibility = "hidden";
        document.getElementById("row3").style.visibility = "hidden";
        document.getElementById("row4").style.visibility = "hidden";
    }

    members.forEach(function (element){
        var li = document.createElement("LI");
        var buttonE = document.createElement('button');
        buttonE.innerText = element.name;
        buttonE.setAttribute("id","goProfle");
        li.append(buttonE);
        buttonE.onclick = function() {
            //basılan profili burada tutabiliriz şuan ad olarak tutuyor
            localStorage.setItem("visitedStudentProfile",element.name);
            window.location="StudentProfile.html";
        }
        document.getElementById("members").appendChild(li);
    });
    addArtifacts();





}

function addArtifacts (){

        let createA = document.createElement('a');
        createA.setAttribute('href', artifact.url);
        let createLabel = document.createElement("P");
        createLabel.innerText = artifact.comment;
        createA.innerText = artifact.url;
        document.getElementById("groupDescription").append(createLabel);
        document.getElementById("groupDescription").append(createA);


}
function sendReview() {

    let li = document.createElement("LI");
    let name = document.getElementById("artifactName").value;
    let reviewContent = document.getElementById("content").value;
    let Label1 = document.createElement("div");
    let Label2 = document.createElement("P");
    Label1.innerText =localStorage.getItem(name)+" : "+ name;
    Label2.innerText = reviewContent;
    li.append(Label1);
    li.append(Label2);
    if(li.innerHTML != ""){
        document.getElementById("reviews").appendChild(li);
    }

    console.log(li.innerHTML);
    document.getElementById("artifactName").value = "";
    document.getElementById("content").value = "";

}