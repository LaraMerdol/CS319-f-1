let defaultThemeColors = Survey.StylesManager.ThemeColors["modern"];
defaultThemeColors["$header-color"] = "#AFAEB4"
defaultThemeColors["$answer-background-color"] = "#AFAEB4";
defaultThemeColors["$main-hover-color"] = "#AFAEB4";
defaultThemeColors["$main-color"] = "#AFAEB4";

Survey.StylesManager.applyTheme("modern");



function getPeerQuestion() {
    let httpRequest = new XMLHttpRequest();
    httpRequest.overrideMimeType("application/json");
    httpRequest.open("GET", 'http://localhost:8080/PeerReviewController/getPeerReviewQuestions');
    httpRequest.onload = function () {
        let questions = httpRequest.responseText;
        alert(questions);
        return questions;
    }
    httpRequest.send();
}
let json1 = {
    "pages": [
        {
            "name": "page1",
            "elements": [
                {
                    "type": "rating",
                    "name": "satisfaction",
                    "title": "How satisfied are you with the Product?",
                    "mininumRateDescription": "Not Satisfied",
                    "maximumRateDescription": "Completely satisfied"
                }, {
                    "type": "panel",
                    "innerIndent": 1,
                    "name": "panel1",
                    "title": "Please, help us improve our product",
                    "visibleIf": "{satisfaction} < 3",
                    "elements": [
                        {
                            "type": "checkbox",
                            "choices": [
                                {
                                    "value": "1",
                                    "text": "Customer relationship"
                                }, {
                                    "value": "2",
                                    "text": "Service quality"
                                }, {
                                    "value": "3",
                                    "text": "Support response time"
                                }
                            ],
                            "name": "What should be improved?"
                        }, {
                            "type": "comment",
                            "name": "suggestions",
                            "title": "What would make you more satisfied with the Product?"
                        }, {
                            "type": "panel",
                            "innerIndent": 1,
                            "name": "panel2",
                            "title": "Send us your contact information (optionally)",
                            "state": "collapsed",
                            "elements": [
                                {
                                    "type": "text",
                                    "name": "name",
                                    "title": "Name:"
                                }, {
                                    "type": "text",
                                    "inputType": "email",
                                    "name": "email",
                                    "title": "E-mail"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};

let json = getPeerQuestion();

window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
            alert( JSON.stringify(result.data, null, 3));
    });

survey.data = {
    satisfaction: 2
};

$("#surveyElement").Survey({model: survey});