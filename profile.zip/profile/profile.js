function myFunction() {
    document.getElementById("name").innerHTML =" Name : "+ localStorage.getItem("name");
    document.getElementById("surname").innerHTML =" Surname : "+ "Merdol";//localStorage.getItem("name");
    document.getElementById("Email").innerHTML =" Email : "+ "lara.merdol@gmail.com";//localStorage.getItem("Email");
    document.getElementById("Course").innerHTML =" Course : "+ "CS319";//localStorage.getItem("Course");
    document.getElementById("Semester").innerHTML =" Semester : "+ "2020-2021 Spring";//localStorage.getItem("Semester");
    document.getElementById("Section").innerHTML =" Section : "+ "3";//localStorage.getItem("Section");
    document.getElementById("Group").innerHTML =" Group : "+ "group-f";//localStorage.getItem("Group");
    //yukarıdaki kodları düzeltmeyi unutma

}
//for show how to use


//write your code here
let reviews1 = new Array();
reviews1.push("Peer Review of Student 1");
let reviews2 = new Array();
reviews2.push("Peer Review of Student 2");
let reviews3 = new Array();
reviews3.push("Peer Review of Student 3");
let reviews4 = new Array();
reviews4.push("Peer Review of Student 4");
reviews4.push("Peer Review of Student 4");
reviews4.push("Peer Review of Student 4");


let student1 = { review: reviews1 , name: "Student1" };
let student2 = { review: reviews2 , name: "Student2" };
let student3 = { review: reviews3 , name: "Student3" };
let student4 = { review: reviews4 , name: "Student4" };

//peers od student
let students = new Array();
students.push(student1);
students.push(student2);
students.push(student3);
students.push(student4);
// need a stude
students.forEach(function (element){
    var li = document.createElement("LI");
    li.value = element;
    var buttonE = document.createElement('button');
    buttonE.innerText = element.name;
    li.append(buttonE);
    buttonE.onclick = function() {
        currentStudent={ review: element.review, name: element.name};
        if(document.getElementById("questions").innerHTML!==""){
            document.getElementById("questions").innerHTML="";
        }
        renew();
    };
    document.getElementById("students").appendChild(li);
});



function renew () {
    currentStudent.review.forEach(function(element){
        let  li = document.createElement("LI");
        li.value = element;
        let label = document.createElement('label');
        //question
        label.innerText = element;
        li.append(label);
        document.getElementById("questions").appendChild(li);
    });

}

