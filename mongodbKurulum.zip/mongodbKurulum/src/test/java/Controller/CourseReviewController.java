package Controller;
import Entity.*;
import DataBase.mongoDB;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class CourseReviewController {

    public static  mongoDB database;

    public CourseReviewController()
    {
        database = new mongoDB();
    }

    public boolean insertOpenEndedQuestionCourse(String question)
    {

        return database.insertOpenEndedQuestionCourse(question);
    }

    public boolean insertMultipleChoiceQuestionCourse(String question, ArrayList<String> choices)
    {
        return database.insertMultipleChoiceQuestionCourse(question,choices);
    }

    public boolean insertPointQuestionCourse(String question, int outOfGrade)
    {
        return database.insertPointQuestionCourse(question,outOfGrade);
    }

    public ArrayList<Question> getCourseReviewQuestions()
    {
        return database.getCourseReviewQuestions();
    }

    public boolean giveAnswerQuestionsCourse(int giverId, ArrayList<String> answer)
    {
        return database.giveAnswerQuestionsCourse(giverId,answer);
    }
    public ArrayList<ArrayList<String>> getCourseReviewAnswers()
    {
        return database.getCourseReviewAnswers();
    }

}
