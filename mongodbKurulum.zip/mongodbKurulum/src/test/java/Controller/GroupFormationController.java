package Controller;
import Entity.*;
import DataBase.mongoDB;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class GroupFormationController {
    private  mongoDB database;
    private ArrayList<User> membersOfGroup;

    public GroupFormationController(){
        database = new mongoDB();
    }


    public  ArrayList<Integer> randomGenerator(int size, int sectionID) {
        int numberOfStudent = database.getNumberOfStudentsFromSection(sectionID);
        int groupSize = size;

        ArrayList<Integer> idOfStudentsInSection = database.getAllStudentsIdFromSection(sectionID);

        Collections.shuffle(idOfStudentsInSection, new Random());

        char groupName = 'a';
        int index =0;
        for (int i = 0; i < (Integer) (numberOfStudent / groupSize); i++, groupName++) {
            String groupID = "CS319-" + sectionID + groupName;

            // database
            database.createGroup(groupID);
            for (int whileIndex = 0; whileIndex < groupSize; whileIndex++, index++) {
                database.insertStudentToGroup(groupID, idOfStudentsInSection.get(whileIndex + groupSize * i), sectionID);
            }
        }
        if(index == numberOfStudent)
        {
            return null;
        }
        ArrayList<Integer> remainStudents = new ArrayList<Integer>();
        for(int i = index;  i < numberOfStudent; i++)
        {
            remainStudents.add(idOfStudentsInSection.get(i));
        }
        return remainStudents;
    }


    public void notRandomGenerator(int sectionID, int studentID)
    {
        database.createGroupByUser(sectionID,studentID);
    }
    public void notRandomGeneratorAddMember(int studentID, String groupName,int sectionID)
    {
        database.insertStudentToGroup(groupName,studentID,sectionID);
    }

    public boolean removeUserFromGroup(int studentID) {
        return database.removeUserFromGroup(studentID);
    }


}
