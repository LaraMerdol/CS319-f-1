package Controller;
import Entity.*;
import DataBase.mongoDB;

import java.util.Hashtable;

public class ArtifactReviewController
{
    public static  mongoDB database;

    public ArtifactReviewController()
    {
        database = new mongoDB();
    }

    public boolean giveArtifactReviewToGroup(String groupName, String artifactType, String answer, int giverID)
    {
        return database.giveArtifactReviewToGroup(groupName, artifactType, answer, giverID);

    }

    public Hashtable<Integer,String> getArtifactReviewFromGroup(String groupName, String artifactType)
    {
        return database.getArtifactReviewFromGroup(groupName,artifactType);
    }

}
