package Controller;
import Entity.*;
import DataBase.*;

import java.util.ArrayList;

public class SectionController {
    private  mongoDB database;

    public SectionController(){ database = new mongoDB();}

    public boolean addSection(int sectionNumber, int instructorID)
    {
        return database.createSection(sectionNumber, instructorID);
    }
    public boolean addUserToSection(int schoolID, int sectionNumber, String userRole)
    {
        return database.insertUserToSection(schoolID, sectionNumber, userRole);
    }

}
