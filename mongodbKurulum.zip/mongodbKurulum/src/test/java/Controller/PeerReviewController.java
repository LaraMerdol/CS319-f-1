package Controller;
import Entity.*;
import DataBase.mongoDB;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import java.util.ArrayList;

public class PeerReviewController {

    public static  mongoDB database;

    public PeerReviewController()
    {
        database = new mongoDB();
    }

    public boolean insertOpenEndedQuestion(String question)
    {
        return database.insertOpenEndedQuestion(question);
    }

    public boolean insertMultipleChoiceQuestion(String question, ArrayList<String> choices)
    {
        return database.insertMultipleChoiceQuestion(question,choices);
    }

    public boolean insertPointQuestion(String question, int outOfGrade)
    {
        return database.insertPointQuestion(question,outOfGrade);
    }

    public ArrayList<Question> getPeerReviewQuestions()
    {
        return database.getPeerReviewQuestions();
    }

    public boolean giveAnswerQuestions(int giverId, int receiverId, ArrayList<String> answer)
    {
        return database.giveAnswerQuestions(giverId,receiverId,answer);
    }
    public ArrayList<String> getPeerReviewAnswers(int giverID, int receiverID)
    {
        return database.getPeerReviewAnswers(giverID,receiverID);
    }

}
