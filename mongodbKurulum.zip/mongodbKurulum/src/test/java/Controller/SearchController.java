
package Controller;
import Entity.*;
import DataBase.mongoDB;

import java.util.ArrayList;

public class SearchController {
    private  mongoDB database;

    public SearchController(){
        database = new mongoDB();
    }
    public User searchUser(int studentId)
    {
        return database.getUser(studentId);
    }

    public Group searchGroup(String groupName)
    {
        return database.getGroup(groupName);
    }

}
