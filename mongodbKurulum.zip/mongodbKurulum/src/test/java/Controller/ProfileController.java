package Controller;

import DataBase.mongoDB;
import Entity.Instructor;
import Entity.Student;
import Entity.TA;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

public class ProfileController {

    private mongoDB database;

    public ProfileController()
    {
        database = new mongoDB();
    }


    // Student-------------------------------------------------------------------------

    public Student getStudentInformation(int studentID)
    {
        return database.getStudentInformation(studentID);
    }

    // Instructor-------------------------------------------------------------------------

    public Instructor getInstructorInformation(int instructorID)
    {
        return  database.getInstructorInformation(instructorID);
    }

    // TA-------------------------------------------------------------------------

    public TA getTAInformation(int TAid)
    {
        return database.getTAInformation(TAid);
    }

    //-------------------------------------------------------------------------
    public Hashtable<Integer,ArrayList<String >> getSpecificPeerReviewOfStudent(int receiverID)
    {
       return database.getSpecificPeerReviewOfStudent(receiverID);
    }


}
