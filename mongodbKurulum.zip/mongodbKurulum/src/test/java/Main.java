import DataBase.*;
import Controller.*;
import Entity.*;
import java.util.ArrayList;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        mongoDB database = new mongoDB();


        GroupFormationController g1 = new GroupFormationController();
        SignUpController c1 = new SignUpController();
        SectionController s1 = new SectionController();
        PeerReviewController p1 = new PeerReviewController();
        ArrayList<Question> q1 = new ArrayList<Question>();
        ArrayList<String> answers = new ArrayList<String>();
        ArrayList<String> answersPeer = new ArrayList<String>();
        ProfileController pc1 = new ProfileController();
        ArtifactReviewController arc = new ArtifactReviewController();
        CourseReviewController crc = new CourseReviewController();


/*


        User user1 = new User("sıla", "asdas","@gmail.com", "1234", 110,"student");
        User user2 = new User("mami", "b","sdsds", "1234", 111,"student");
        User user3 = new User("beko", "sd","asdas", "1234", 112,"student");
        User user4 = new User("beko", "sd","asdas", "1234", 113,"student");
        User user5 = new User("beko", "sd","asdas", "1234", 114,"student");
        User user6 = new User("sadsadasdas", "sd","asdas", "1234", 1111,"instructor");

        c1.signUp(user1.getName(), user1.getSurname(),user1.getEmail(), user1.getPassword(),user1.getSchoolId(),user1.getUserRole());
        c1.signUp(user2.getName(), user2.getSurname(),user2.getEmail(), user2.getPassword(),user2.getSchoolId(),user2.getUserRole());
        c1.signUp(user3.getName(), user3.getSurname(),user3.getEmail(), user3.getPassword(),user3.getSchoolId(),user3.getUserRole());
        c1.signUp(user4.getName(), user4.getSurname(),user4.getEmail(), user4.getPassword(),user4.getSchoolId(),user4.getUserRole());
        c1.signUp(user5.getName(), user5.getSurname(),user5.getEmail(), user5.getPassword(),user5.getSchoolId(),user5.getUserRole());
        c1.signUp(user6.getName(), user6.getSurname(),user6.getEmail(), user6.getPassword(),user6.getSchoolId(),user6.getUserRole());


        c1.signUp(user6.getName(), user6.getSurname(),user6.getEmail(), user6.getPassword(),user6.getSchoolId(),user6.getUserRole());

        s1.addSection(1,1111);

        s1.addUserToSection(110,1,"student");
        s1.addUserToSection(111,1,"student");
        s1.addUserToSection(112,1,"student");
        s1.addUserToSection(113,1,"student");
        s1.addUserToSection(114,1,"student");

        // g1.notRandomGenerator(1,111);
        //g1.removeUserFromGroup(111);


        p1.insertOpenEndedQuestion("what is your group members work allocations");
        p1.insertPointQuestion("uyumunuza kaç puan verirsin", 5);
        ArrayList<String> choice = new ArrayList<String>();
        choice.add("uykucu");
        choice.add("çalışkan");
        choice.add("tembel");
        p1.insertMultipleChoiceQuestion("Takım arkadaşının tarifi nedir", choice);
        p1.insertOpenEndedQuestion("What is your member");



        q1 = p1.getQuestions();
        for(int i = 0; i < q1.size(); i++)
        {
            System.out.println(q1.get(i).getQuestion());
        }


         g1.notRandomGenerator(1,110);
         g1.notRandomGeneratorAddMember(111,"CS319-1a",1);
         answers.add("goood");
         answers.add("3");
         answers.add("tembel");
         answers.add("sıla");
        p1.giveAnswerQuestions(110,111,answers);
        p1.giveAnswerQuestions(110,112,answers);
        p1.giveAnswerQuestions(113,110,answers);


        answersPeer = p1.getPeerReviewAnswers(110,111);
        for(int i = 0; i < answersPeer.size(); i++)
        {
            System.out.println(answersPeer.get(i));
        }

        Student student = pc1.getStudentInformation(110);

        System.out.println(student.getName());
        System.out.println(student.getSurname());
        System.out.println(student.getEmail());
        System.out.println(student.getPassword());
        System.out.println(student.getSection());
        System.out.println(student.getGroupId());

        s1.addSection(2,1111);

        Instructor instructor = pc1.getInstructorInformation(1111);

        System.out.println(instructor.getName());
        System.out.println(instructor.getSurname());
        System.out.println(instructor.getEmail());
        System.out.println(instructor.getPassword());
        System.out.println(instructor.getTAlist());
        System.out.println(instructor.getSections());


        TA ta= pc1.getTAInformation(10);
        System.out.println(ta.getName());
        System.out.println(ta.getSurname());
        System.out.println(ta.getEmail());
        System.out.println(ta.getPassword());
        System.out.println(ta.getSections());
*/
       // System.out.println((g1.randomGenerator(2,1).get(0)));


       // g1.notRandomGenerator(1,111);
        //g1.notRandomGeneratorAddMember(111, "CS319-1a",1);
        //g1.notRandomGeneratorAddMember(114, "CS319-1d",1);


        //g1.notRandomGeneratorAddMember(113,"CS319-1g",1);

        //g1.notRandomGeneratorAddMember(110,"CS319-1c",1);

        //g1.notRandomGeneratorAddMember(111,"C");


        //System.out.println(g1.randomGenerator(5,1).get(0));

       // database.insertStudentToGroup("group1",333,1);

/*
        g1.notRandomGeneratorAddMember(112,"CS319-1a",1);
        answers.add("asdsa");
        answers.add("5");
        answers.add("asdsa");
        answers.add("323232322");

        p1.giveAnswerQuestions(112,111,answers);


    System.out.println(pc1.getSpecificPeerReviewOfStudent(111));



        arc.giveArtifactReviewToGroup("CS319-1a","Analysis Report", "çok iyi bir rapor olmuş",110);
        arc.giveArtifactReviewToGroup("CS319-1a","Analysis Report", "çok iyi bir rapor olmuş",113);

        System.out.println(arc.getArtifactReviewFromGroup("CS319-1a","Analysis Report"));


       // crc.insertOpenEndedQuestionCourse("what is your group members work allocations");
       // crc.insertPointQuestionCourse("uyumunuza kaç puan verirsin", 5);
       // ArrayList<String> choice = new ArrayList<String>();
       // choice.add("uykucu");
       // choice.add("çalışkan");
       // choice.add("tembel");
       // crc.insertMultipleChoiceQuestionCourse("Takım arkadaşının tarifi nedir", choice);
       // crc.insertOpenEndedQuestionCourse("What is your member");

     //   q1 = crc.getCourseReviewQuestions();
     //   for(int i = 0; i < q1.size(); i++)
     //   {
     //       System.out.println(q1.get(i).getQuestion());
     //   }

      //  answers.add("goood");
      //  answers.add("3");
     //   answers.add("tembel");
       // answers.add("sıla");

     //   crc.giveAnswerQuestionsCourse(111,answers);

       ArrayList<ArrayList<String>> answersCourse = crc.getCourseReviewAnswers();
        for(int i = 0; i <answersCourse.size(); i++)
        {
            System.out.println(answersCourse.get(i));
        }

         */



    }
}



