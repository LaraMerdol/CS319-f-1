package Entity;
import java.util.ArrayList;

/**
 * This class is the Instructor Entity extended from User class.
 */
public class Instructor extends User {
    // Variables
    private ArrayList<Integer> sections;
    private ArrayList<ArrayList<Integer>> TAlist;

    // constructors
    /**
     * This class is the default constructor of Instructor class.
     */
    public Instructor() {}


    public Instructor(String name, String surname, String email, String password, int schoolId,
                      ArrayList<Integer> sections, ArrayList<ArrayList<Integer>> TAlist)
    {
       super(name,surname,email,password, schoolId, "instructor");
        this.sections = sections;
        this.TAlist = TAlist;
    }

    public ArrayList<ArrayList<Integer>> getTAlist() {
        return TAlist;
    }

    public void setTAlist(ArrayList<ArrayList<Integer>> taList) {
        this.TAlist = TAlist;
    }

    public ArrayList<Integer> getSections() {
        return sections;
    }

    public void setSections(ArrayList<Integer> sections) {
        this.sections = sections;
    }
}
